মারকাযুস সুন্নাহ মাদ্রাসা Android App Project

APK বানাতে:
1. Android Studio ইনস্টল করুন।
2. এই ZIP Extract করুন।
3. Android Studio > Open > MadrasaApp ফোল্ডার নির্বাচন করুন।
4. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
5. Build > Build APK(s) নির্বাচন করুন।
6. app/build/outputs/apk/debug/app-debug.apk ফাইলটি পাবেন।

অ্যাপটি বর্তমানে HTML ভিত্তিক Demo এবং Offline WebView হিসেবে চলে।
